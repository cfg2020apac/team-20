from django.apps import AppConfig


class RecommendEventsConfig(AppConfig):
    name = 'recommend_events'
